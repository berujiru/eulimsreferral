<?php
use yii\helpers\Html;
use kartik\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
?>

<div class="notification-view notification-display">
<div class="alert alert-info" style="border-bottom: 2px solid #555;margin-bottom:2px;">
  <strong style="color:#000;">List of Notifications</strong>
</div>
  <ul>
	<?php if($count_notice > 0 && $count_notice > 3) : ?>
	<!--<li class="label-action">Action is needed</li>-->
		<?php foreach($notifications as $notification): ?>
		<?php if($notification['owner'] == 1): ?>
		<a href='<?= "/lab/request/view?id=".$notification['local_request_id'] ?>'>
			<li>
				<?= $notification['notice_sent'] ?><br>
				<span class="notification-date"><?= date("d-M-Y g:i A", strtotime($notification['notification_date'])) ?></span>
			</li>
		</a>
		<?php else: ?>
		<a href='<?= "/referrals/referral/view?id=".$notification['referral_id']."&notice_id=".$notification['notice_id'] ?>'>
			<li>
				<?= $notification['notice_sent'] ?><br>
				<span class="notification-date"><?= date("d-M-Y g:i A", strtotime($notification['notification_date'])) ?></span>
			</li>
		</a>
		<?php endif; ?>
		<?php endforeach; ?>
		<button type="button" class="btn btn-primary btn-xs btn-block" style="font-size:13px;">Load more</button>
	<?php elseif($count_notice > 0 && $count_notice <= 3): ?>
		<?php foreach($notifications as $notification): ?>
		<?php if($notification['owner'] == 1): ?>
		<a href='<?= "/lab/request/view?id=".$notification['local_request_id']."&notice_id=".$notification['notice_id'] ?>'>
			<li>
				<?= $notification['notice_sent'] ?><br>
				<span class="notification-date"><?= date("d-M-Y g:i A", strtotime($notification['notification_date'])) ?></span>
			</li>
		</a>
		<?php else: ?>
		<a href='<?= "/referrals/referral/view?id=".$notification['referral_id']."&notice_id=".$notification['notice_id'] ?>'>
			<li>
				<?= $notification['notice_sent'] ?><br>
				<span class="notification-date"><?= date("d-M-Y g:i A", strtotime($notification['notification_date'])) ?></span>
			</li>
		</a>
		<?php endif; ?>
		<?php endforeach; ?>
	<?php else: ?>
		<li>No notification.</li>
	<?php endif; ?>
  </ul>

<?php

//print_r($notificationProvider);

Pjax::begin([
	'enablePushState' => true, // to disable push state
	'enableReplaceState' => true // to disable replace state
]);
echo ListView::widget([
    'dataProvider' => $notificationProvider,
    'itemOptions' => ['class' => 'item'],
    'itemView' => '_list_item',
    'summary' => false,
    'pager' => [
    	'class' => \kop\y2sp\ScrollPager::className(),
    	'noneLeftText' => 'No more notifications left to load.',
    	'spinnerSrc' => '/images/img-png-loader-24.png',
    	'triggerText' => 'Load more',
    	'enabledExtensions' => [ 
    		\kop\y2sp\ScrollPager::EXTENSION_TRIGGER,
    		\kop\y2sp\ScrollPager::EXTENSION_SPINNER,
    		\kop\y2sp\ScrollPager::EXTENSION_NONE_LEFT,
    		\kop\y2sp\ScrollPager::EXTENSION_PAGING,
    	],
    ]
]);
Pjax::end();

/* echo GridView::widget([
     'dataProvider' => $notificationProvider,
     'columns' => [
     	[
            'attribute'=>'notification_id',
            'enableSorting' => false,
            'contentOptions' => [
                'style'=>'max-width:70px; overflow: auto; white-space: normal; word-wrap: break-word;'
            ],
            'format' => 'raw',
            'value' => function($data){
            	return $data['notification_id'];
            }
        ],
        [
            'attribute'=>'referral_id',
            'enableSorting' => false,
            'contentOptions' => [
                'style'=>'max-width:70px; overflow: auto; white-space: normal; word-wrap: break-word;'
            ],
            'format' => 'raw',
            'value' => function($data){
            	return $data['referral_id'];
            }
        ],
     ],
    'pjax'=>true,
    'pjaxSettings' => [
        'options' => [
            'enablePushState' => false,
        ]
    ],
    'pager' => [
        'class' => \kop\y2sp\ScrollPager::className(),
        'container' => '.grid-view tbody',
        'item' => 'tr',
        'paginationSelector' => '.grid-view .pagination',
        'triggerTemplate' => '<tr class="ias-trigger"><td colspan="100%" style="text-align: center"><a style="cursor: pointer">{text}</a></td></tr>',
    ],
]);*/

?>

</div>

<style type="text/css">
.notification-display ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.notification-display li {
  border-bottom: 1px solid #888;
  padding: 4px 15px 4px 15px;
  background: #ebf7e6;
  font-size: 12px;
  color: #444;
}

.notification-display li:hover {
  background: #fff5d4;
  cursor: pointer;
}

.notification-display li.see-all {
	text-align: center;
	padding: 5px;
	background: #3c8dbc;
	color: #ffffff;
}
.notification-display li.label-action {
	padding: 2px 20px 2px 20px;
	background: #eee;
	font-size:12px;
	text-transform: uppercase;
	font-weight: bold;
	color: #555;
}
.notification-display .notification-date {
	color: #777;
	font-size: 11px;
}
.notification-display a:link, a:hover, a:active {
	text-decoration: none;
	display: block;
	background-color:none;
	color: #444;
}
</style>

