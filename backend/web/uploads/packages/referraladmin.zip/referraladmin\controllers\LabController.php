<?php

namespace frontend\modules\referraladmin\controllers;

class LabController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
