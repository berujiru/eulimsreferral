<?php

namespace frontend\modules\referraladmin\controllers;

class LabsampletypeController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
